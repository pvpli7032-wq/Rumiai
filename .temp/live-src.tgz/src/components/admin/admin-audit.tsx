'use client';
import {useEffect, useState} from 'react';
import {auditLabels} from './accounts/types';
import {useAdminAccess} from './use-admin-access';

type Audit = {id: string; actorId: string; action: string; targetId: string; reason: string; changes: string; createdAt: string};
const actionNames: Record<string, string> = {...auditLabels, BOOTSTRAP_OWNER: '初始化所有者', SAVE_OPERATOR: '修改管理身份', CREATE_ROLE: '新增角色', UPDATE_ROLE: '修改角色', ACCOUNT_CLOSED: '注销管理账号', CHARACTER_CREATED: '新增角色', CHARACTER_EDITED: '修改角色内容', CHARACTER_APPROVED: '角色审核通过', CHARACTER_REJECTED: '角色退回或下架', CIRCLE_CREATED: '新增站点圈子', CIRCLE_SAVE: '修改圈子内容', CIRCLE_HIDE: '隐藏圈子', CIRCLE_RESTORE: '恢复圈子公开', CIRCLE_FEATURE: '推荐圈子', CIRCLE_UNFEATURE: '取消圈子推荐', CIRCLE_MEMBER_REMOVE: '移除圈子成员', CIRCLE_MEMBER_BLOCK: '限制圈子加入', CIRCLE_MEMBER_UNBLOCK: '解除圈子加入限制'};
export function AdminAudit() {
  const {token, access, loading, error: accessError} = useAdminAccess();
  const [page, setPage] = useState(1), [refresh, setRefresh] = useState(0);
  const emptyFilters={actorId:'',targetId:'',action:'',from:'',until:''};
  const [draft,setDraft]=useState(emptyFilters),[filters,setFilters]=useState(emptyFilters);
  const [result, setResult] = useState<{items: Audit[]; total: number; pageSize: number} | null>(null);
  const [error, setError] = useState(''), [reading, setReading] = useState(false);
  useEffect(() => {
    setResult(null); setError(''); if (!token || !access?.audit) return;
    const controller = new AbortController(); setReading(true);
    void (async () => {
      try {const params=new URLSearchParams({...filters,page:String(page)});const response = await fetch(`/api/admin/audit?${params}`, {headers: {Authorization: `Bearer ${token}`}, cache: 'no-store', signal: controller.signal}); const data = await response.json(); if (!response.ok) throw Error(data.error || '读取审计失败。'); if (!controller.signal.aborted) setResult(data);}
      catch (value) {if (!controller.signal.aborted) setError((value as Error).message);}
      finally {if (!controller.signal.aborted) setReading(false);}
    })();
    return () => controller.abort();
  }, [token, access?.audit, page, refresh,filters]);
  if (loading) return <p role="status" className="p-6">正在读取管理权限…</p>;
  if (!token || !access?.audit) return <p role="alert" className="p-6">{accessError || '当前账号没有管理审计权限。'}</p>;
  return <main className="mx-auto max-w-6xl space-y-4 p-4 md:p-6"><div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl font-bold">管理操作审计</h1><button className="min-h-11 rounded-lg border px-4" disabled={reading} onClick={() => setRefresh(value => value + 1)}>刷新审计</button></div>
    <form className="grid gap-3 rounded-xl border p-4 sm:grid-cols-2 lg:grid-cols-3" onSubmit={event=>{event.preventDefault();setPage(1);setFilters({...draft});}}>
      {([['actorId','操作人ID'],['targetId','对象ID'],['action','动作代码'],['from','开始日期（UTC）'],['until','结束日期（UTC）']] as const).map(([key,label])=><label key={key} className="min-w-0 text-sm">{label}<input type={key==='from'||key==='until'?'date':'text'} maxLength={100} value={draft[key]} onChange={event=>setDraft({...draft,[key]:event.target.value})} className="mt-1 min-h-11 w-full min-w-0 rounded-lg border bg-background px-3"/></label>)}
      <div className="flex items-end gap-2"><button disabled={reading} className="min-h-11 rounded-lg border px-4">筛选审计</button><button type="button" disabled={reading} className="min-h-11 rounded-lg border px-4" onClick={()=>{setDraft(emptyFilters);setFilters(emptyFilters);setPage(1);}}>重置筛选</button></div>
      <p className="text-xs text-muted-foreground sm:col-span-2 lg:col-span-3">ID与动作代码精确匹配；日期按UTC日统计，包含结束日期当天。</p>
    </form>
    {error && <p role="alert" className="text-red-400">{error}</p>}{reading && <p role="status">正在读取审计…</p>}
    {result && <><div className="max-w-full overflow-x-auto rounded-xl border"><table className="w-full min-w-[760px] text-left text-sm"><thead><tr className="border-b"><th className="p-3">时间</th><th className="p-3">操作</th><th className="p-3">操作人 / 对象</th><th className="p-3">理由及变更</th></tr></thead><tbody>{result.items.map(item => <tr key={item.id} className="border-b align-top"><td className="whitespace-nowrap p-3">{new Date(item.createdAt).toLocaleString('zh-CN')}</td><td className="p-3">{actionNames[item.action] ?? item.action}</td><td className="max-w-64 break-all p-3"><p>{item.actorId}</p><p className="mt-1 text-muted-foreground">{item.targetId}</p></td><td className="max-w-xl break-words p-3"><p>{item.reason}</p><details className="mt-2"><summary className="cursor-pointer">查看修改内容</summary><pre className="mt-2 whitespace-pre-wrap break-all text-xs">{item.changes}</pre></details></td></tr>)}</tbody></table></div>
    {!result.total && <p>暂无管理操作记录。</p>}<div className="flex flex-wrap items-center gap-3"><span>共 {result.total} 条 · 第 {page} 页</span><button className="min-h-11 rounded-lg border px-4 disabled:opacity-50" disabled={reading || page === 1} onClick={() => setPage(page - 1)}>上一页</button><button className="min-h-11 rounded-lg border px-4 disabled:opacity-50" disabled={reading || page * result.pageSize >= result.total} onClick={() => setPage(page + 1)}>下一页</button></div></>}
  </main>;
}
