import type { MetadataRoute } from 'next';
import { SITE_URL } from '@/lib/i18n';

/** Mirrors the live site's robots.txt. */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/api/', '/_next/', '/static/'] }],
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
