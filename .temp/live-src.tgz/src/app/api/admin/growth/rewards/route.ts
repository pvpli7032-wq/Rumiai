import {NextResponse} from 'next/server';
import {getAuthUser} from '@/lib/auth';
import {readRewardBudgetReport,RewardBudgetReportError} from '@/lib/growth/reward-budget-service';
import {logRouteError} from '@/lib/logger';

export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store'};

export async function GET(request:Request){
  const auth=await getAuthUser(request);
  if(!auth)return NextResponse.json({error:'请先登录。'},{status:401,headers});
  const days=Number(new URL(request.url).searchParams.get('days')??7);
  try{return NextResponse.json(await readRewardBudgetReport(auth.userId,days),{headers});}
  catch(error){
    if(error instanceof RewardBudgetReportError)return NextResponse.json({error:error.message},{status:error.status,headers});
    logRouteError('GET /api/admin/growth/rewards',error);return NextResponse.json({error:'奖励发放统计读取失败。'},{status:500,headers});
  }
}
