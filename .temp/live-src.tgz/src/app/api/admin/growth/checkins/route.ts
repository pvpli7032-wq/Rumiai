import {NextResponse} from 'next/server';
import {getAuthUser} from '@/lib/auth';
import {CheckinManagementError,readCheckinRules,saveCheckinRules} from '@/lib/checkins/management-service';
import {logRouteError} from '@/lib/logger';

export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store'};

export async function GET(request:Request){
  const auth=await getAuthUser(request);
  if(!auth)return NextResponse.json({error:'请先登录。'},{status:401,headers});
  try{return NextResponse.json(await readCheckinRules(auth.userId),{headers});}
  catch(error){
    if(error instanceof CheckinManagementError)return NextResponse.json({error:error.message},{status:error.status,headers});
    logRouteError('GET /api/admin/growth/checkins',error);return NextResponse.json({error:'签到奖励读取失败。'},{status:500,headers});
  }
}

export async function PUT(request:Request){
  const auth=await getAuthUser(request);
  if(!auth)return NextResponse.json({error:'请先登录。'},{status:401,headers});
  try{return NextResponse.json(await saveCheckinRules(auth.userId,await request.json()),{headers});}
  catch(error){
    if(error instanceof CheckinManagementError)return NextResponse.json({error:error.message},{status:error.status,headers});
    logRouteError('PUT /api/admin/growth/checkins',error);return NextResponse.json({error:'签到奖励保存失败。'},{status:500,headers});
  }
}
